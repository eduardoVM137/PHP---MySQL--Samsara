<?php
define("urlsite","http://localhost/php-modelo");