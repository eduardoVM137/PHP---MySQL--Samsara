<?php
define("urlsite","http://localhost/index.php");
?>